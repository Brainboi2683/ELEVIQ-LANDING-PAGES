ELEVIQ PRODUCT 5 UPDATE — ANDROID UPLOAD GUIDE

FILES IN THIS ZIP
1. product5.html — updated Product 5 landing page; the form is configured to redirect to thank-you.html after FormSubmit processes a successful submission.
2. thank-you.html — mobile-friendly confirmation page.

IMPORTANT
- Upload BOTH HTML files to the root of your ELEVIQ-LANDING-PAGES GitHub repository.
- Replace the existing product5.html with the supplied product5.html.
- Add thank-you.html as a new file.
- Keep the existing eleviq-logo.png in the same repository folder; this package does not replace your logo.
- FormSubmit may require email activation/confirmation the first time the form is used. Test the form after deployment.
- The redirect URL currently points to https://brainboi2683.github.io/ELEVIQ-LANDING-PAGES/thank-you.html

On Android, extract this ZIP in Files/File Manager, then upload the two .html files separately through GitHub's website. GitHub does not automatically extract ZIP uploads into a repository.
